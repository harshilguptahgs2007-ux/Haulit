import React from "react"

function Order():React.ReactElement {
  return (
    <div>order</div>
  )
}

export default Order