import React from "react"
import Carousel from "../components/carousel"

function Home():React.ReactElement {
  return (
    <div className="flex flex-row self-center
    m-[4rem] gap-14 text-2xl items-center
    ">
      <Carousel/>
      <div className="flex flex-col w-2xl gap-10">
        <h1 className="text-slate-900 text-8xl font-bold">LETS <span className="text-red-600">HAULIT</span> INDIA!</h1>
        Samaan bhejna har baar complicated ya expensive nahi hona chahiye. Haulit ek small scale logistics platform hai jo customers ko local truck owners se connect karta hai, taaki goods ko affordable rates par easily transport kiya ja sake.

Chahe aap small business owner ho, retailer ho, manufacturer ho, ya simply kuch samaan bhejna chahte ho, Haulit transportation ko simple banata hai. Pickup aur delivery details share karo, suitable truck choose karo, aur shipment easily book karo.

Haulit ka focus simple hai. Local truck network ko better utilize karna aur customers ko reliable, affordable transportation dena. Haulit ke saath, logistics simple hai. Aapka samaan, sahi truck, sahi rate.

      </div>
    </div>
  )
}

export default Home