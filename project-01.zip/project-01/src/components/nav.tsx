import React from "react"
import { NavLink, useLocation } from "react-router-dom"
import logo from "../assets/haulit.png"

const NAV_ITEMS = [
  { to: "/", label: "Home" },
  { to: "/order", label: "Order" },
  { to: "/track", label: "Track" },
] as const

const ITEM_WIDTH = 100 // px, keep in sync with the w-[90px] below

function Navbar(): React.ReactElement {
  const location = useLocation()

  const activeIndex = Math.max(
    0,
    NAV_ITEMS.findIndex((item) => item.to === location.pathname)
  )

  return (
    <div className="flex flex-row w-full text-3xl bg-slate-200 shadow-[0px_6px_10px_rgba(0,0,0,0.1)] items-center justify-between text-black px-8 py-4">

      <span className="flex flex-row text-gray-700 items-center font-bold">
        <img className="w-20" src={logo} alt="Haulit" />
        HAULIT
      </span>

      <ul className="relative flex flex-row text-xl gap-2 list-none m-0 p-1">

        {/* Sliding block */}
        <div
          aria-hidden
          className="absolute top-1 left-1 h-[44px] w-[90px] rounded-xl bg-gray-200 shadow-[2px_2px_5px_rgba(0,0,0,0.2),-2px_-2px_5px_rgba(255,255,255,1)] transition-transform duration-300 ease-in-out list-none"
          style={{ transform: `translateX(${activeIndex * (activeIndex==1 || activeIndex==2 ? ITEM_WIDTH-2 : ITEM_WIDTH)}px)` }}
        />

        {NAV_ITEMS.map((item) => (
          <li key={item.to} className="z-10 w-[90px] text-center">
            <NavLink to={item.to} className="block px-4 py-2">
              {item.label}
            </NavLink>
          </li>
        ))}

      </ul>
    </div>
  )
}

export default Navbar