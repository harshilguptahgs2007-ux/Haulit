"use client";

import { useEffect, useState } from "react";

const images = [
  "https://i.pinimg.com/736x/43/b9/a7/43b9a721454fe4964e09f5a4e00beba2.jpg",
  "https://i.pinimg.com/736x/37/15/6b/37156b8997e83d5bcfdd7a54160b44cb.jpg",
  "https://i.pinimg.com/736x/ef/1a/be/ef1abe05c1c84642f85914932861edac.jpg",
];

export default function Carousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto change slide
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 3000)

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-row h-[40rem] shadow-[10px_10px_10px_rgba(0,0,0,0.2),-10px_-10px_10px_rgba(255,255,255,1)]  justify-center relative rounded-3xl overflow-hidden">

      {/* Image */}
      <img
        className="w-[25rem] h-[40rem] object-cover"
        src={images[currentIndex]}
        alt={`Slide ${currentIndex + 1}`}
      />

      {/* Dots */}
      <div className="absolute flex flex-row z-50 justify-center gap-2 bottom-4">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              currentIndex === index
                ? "bg-white"
                : "bg-white/50"
            }`}
          />
        ))}
      </div>

    </div>
  );
}