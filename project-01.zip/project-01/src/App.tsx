import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/home'
import Order from './pages/order'
import Track from './pages/track'
import Dashboard from './pages/dashboard'
import Fleet from './pages/fleet'
import logo from "./assets/haulit.png"

function App(): React.ReactElement {
  return (
    <div className="flex flex-col w-full min-h-screen bg-[var(--color-surface-bg)]">
      <Navbar />
      <div className="pt-[88px] flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/order" element={<Order />} />
          <Route path="/track" element={<Track />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/fleet" element={<Fleet />} />
        </Routes>
      </div>
      {/* Neomorphic Footer */}
      <footer className="w-full bg-[var(--color-surface-bg)] pt-[var(--spacing-section-padding-mobile)] pb-12 border-t-2 border-[var(--color-surface-container-highest)]">
        <div className="max-w-[var(--spacing-container-max-width)] mx-auto px-[var(--spacing-gutter)] flex flex-col md:flex-row justify-between items-start gap-8">
          {/* Brand */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-3 bg-[var(--color-surface-bg)] p-4 rounded-2xl neo-shadow-inner w-fit">
              <div className="w-9 h-9 flex flex-col  neo-shadow-sm relative justify-center items-center rounded-full overflow-hidden">
                <img
                  className="absolute w-[3.5rem] mt-0.5 ml-[0.5px] max-w-none "
                  src={logo}
                  alt=""
                />
              </div>
              <span className="text-[var(--text-headline-md)] font-extrabold text-[var(--color-on-surface)] uppercase tracking-tighter">
                HAULIT
              </span>
            </div>
            <p className="text-[var(--text-body-md)] text-[var(--color-secondary)] max-w-sm">
              Simplifying local logistics across India. Reliable trucks, affordable rates.
            </p>
          </div>

          {/* Links + Copyright */}
          <div className="flex flex-col md:items-end gap-8">
            <p className="text-[var(--text-body-md)] text-[var(--color-secondary)] opacity-70">
              © 2024 HAULIT Logistics. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
