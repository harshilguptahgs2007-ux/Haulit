import React, { useState } from 'react'
import { Route,Routes } from 'react-router-dom'
import Home from './pages/home'
import Track from './pages/track'
import Order from './pages/order'
import Navbar from './components/nav'

function App():React.ReactElement {
  return <div className="flex flex-col w-full min-h-screen bg-slate-300">
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/order' element={<Order/>}/>
      <Route path='/track' element={<Track/>}/>
    </Routes>
  </div> 
}

export default App
